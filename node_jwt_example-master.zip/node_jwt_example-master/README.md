# Node.js jsonwebtoken Example

> An example of how to protect routes and get a token

## Quick Start

``` bash
# Install dependencies
npm install

# Serve on localhost:3000
npm start
```